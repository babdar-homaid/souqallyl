// $(document).ready(function(){
//
//     $(".submit").click(function(){
//         window.print()
//
//     });
//
//
//
//
//     });
